package com.trello.qsp.commonrepo;

public class FileUtility {
/**
 * This method will be used to read the data from the property file
 * @author Ankita
 * @param key
 * @return value
 * @throws IOException
 */
	public String readCommonData
}
