package Select;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {
//Evaluation of the Drop down Type
	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.facebook.com/signup");
		
		//Identify the month drop down Element
	WebElement	monthDropDown=driver.findElement(By.id("month"));
       
	//creat the object of select class with the drop down element associted with
	 Select    monthSelect= new Select(monthDropDown);
	 //month ListBox will give us access to the select class of Selenium Lib
	 //isMultiple()will help us to chek the type of the drop down
	 if(monthSelect.isMultiple()) {
		 System.out.println("DRop down is mulipale select -Boolean true");
	
	 }else {
		System.out.println("DRop down is single select -Boolean false");
	}
	driver.manage().window().minimize();
	driver.quit();
	 
		
	}
		 
	 }
	


