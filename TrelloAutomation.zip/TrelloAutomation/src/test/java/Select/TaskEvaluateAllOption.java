package Select;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TaskEvaluateAllOption {
//evaluate
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.facebook.com/signup");
		
		//identify the day drop down
		WebElement dayDropDown= driver.findElement(By.id("day"));
		Select daySelect= new Select(dayDropDown);
		//capture all the default option in the day drop down
		 WebElement dayDefault= daySelect.getFirstSelectedOption();
   System.out.println(dayDefault.getText());
   
 //identify the month drop down
 		WebElement monthDropDown= driver.findElement(By.id("month"));
 		Select monthSelect1= new Select(monthDropDown);
 		//capture all the default option in the day drop down
 		 WebElement monthDefault= monthSelect1.getFirstSelectedOption();
    System.out.println(monthDefault.getText());
    
  //identify the year drop down
		WebElement yearDropDown= driver.findElement(By.id("year"));
		Select yearSelect2= new Select(yearDropDown);
		//capture all the default option in the day drop down
		 WebElement yearDefault= yearSelect2.getFirstSelectedOption();
System.out.println(yearDefault.getText());
      driver.manage().window().minimize();
      driver.quit();
	}

}
