package Select;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CheckForDefaultSelectOption {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.facebook.com/signup");
		
		//identify the drop down button
	WebElement	monthDropDown=driver.findElement(By.id("month"));
   //creat the object of select class with the drop down Element associated with
	Select  monthSelect = new Select(monthDropDown);
   
   //Capture the default selected option as WebElement
	WebElement defaultOption=monthSelect.getFirstSelectedOption();
   
	System.out.println(defaultOption.getText());
	driver.manage().window().minimize();
	driver.quit();
	}

}
