package Select;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TaskCaptureOption {
//capture all the Option present three Drop down
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.facebook.com/signup");
		
		//identify the day drop down button
				WebElement	dayDropDown=driver.findElement(By.id("day"));
				//creat the object of select class with the drop down Element associated with
				Select  daySelect = new Select(dayDropDown);
				//Capture the all selected option as WebElement
				  List<WebElement>   allOptionDay=  daySelect.getOptions();
				  System.out.println("capture all the option in day:"+allOptionDay.size());
				  
				  //print all option in the month list box
				  //iterate each one option
				  for (WebElement dayOption : allOptionDay) {
					
				
					System.out.println(dayOption.getText());
				  }
		
		//identify the month drop down button
		WebElement	monthDropDown=driver.findElement(By.id("month"));
		//creat the object of select class with the drop down Element associated with
		Select  monthSelect = new Select(monthDropDown);
		//Capture the all selected option as WebElement
		  List<WebElement>   allOptionMonth=  monthSelect.getOptions();
		  System.out.println("capture all the option in month:"+allOptionMonth.size());
		  
		  //print all option in the month list box
		  //iterate each one option
		  for (WebElement monthOption : allOptionMonth) {
			 System.out.println(monthOption.getText()); 
			  }
		//identify the year drop down button
		  WebElement	yearDropDown=driver.findElement(By.id("year")); 
		//creat the object of select class with the drop down Element associated with  
	 Select yearSelect=	new Select(yearDropDown) ; 
	//Capture the all selected option as WebElement
	 List<WebElement>   allOptionYear= yearSelect.getOptions();
	 System.out.println("capture all the option in year:"+allOptionYear.size());
	 
	 //print all option in the month list box
	  //iterate each one option
	 for (WebElement yearOption : allOptionYear) {
		 System.out.println(yearOption.getText());
		
	}
	 
        driver.manage().window().minimize();
        driver.quit();
	}
}
