package Select;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectThreeAndCheck {

	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
	     driver.manage().window().maximize();
	     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	     WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(5));
         driver.get("file:///C:/Users/DELL/OneDrive/Desktop/selenium/Dropdown.html");
    Select  dropDownSelect  = new Select(driver.findElement(By.tagName("select")));
    dropDownSelect.deselectByVisibleText("Nov");
    dropDownSelect.selectByIndex(0);
    dropDownSelect.selectByIndex(1);
    dropDownSelect.selectByIndex(2);
    
    //Selected count
 int selectedCount = dropDownSelect.getAllSelectedOptions().size();
 System.out.println("selected count:"+selectedCount);
 
 //What sre the selected option
 for (WebElement option :dropDownSelect.getAllSelectedOptions()) {
	 System.out.println(option.getText());
	 
}
 //deselect all the selected option and confirm for zero
    dropDownSelect.deselectAll();
   int selectedCountAfterDes = dropDownSelect.getAllSelectedOptions().size();
 
 System.out.println("SElectedCountAfterDes:"+selectedCountAfterDes);
 driver.manage().window().minimize();
 driver.quit();
	}

}
