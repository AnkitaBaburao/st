package Select;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TaskForFbdaymonthyear {
	//check count option Day Month and Year Drop Down
	public static void main(String[] args) {
	WebDriver driver= new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	driver.get("https://www.facebook.com/signup");
	
	//identify the day drop down
	WebElement daydropdown = driver.findElement(By.id("day"));
	Select daySelect= new Select(daydropdown);
	//to capture all the option in the list box
	List<WebElement> allOptionDay = daySelect.getOptions();
	System.out.println("count the day drop down:"+allOptionDay.size());	

	//identify the month drop down
	WebElement monthDropDown= driver.findElement(By.id("month"));
	Select monthSelect= new Select(monthDropDown);
	//to capture the option in the list box
	List<WebElement> allOptionMonth= monthSelect.getOptions();
	System.out.println("count the month drop down:"+allOptionMonth.size());
	
	//identify the year drop down
	WebElement yearDropDown= driver.findElement(By.id("year"));
	  Select yearSelect   = new Select(yearDropDown);
	  //to capture the option in the list box
	List<WebElement> allOptionYear = yearSelect.getOptions();
	System.out.println("count the year drop down:"+allOptionYear.size());
	
	driver.manage().window().minimize();
	driver.quit();
	
	
	
	}

}
