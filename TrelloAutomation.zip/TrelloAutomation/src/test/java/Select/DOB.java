package Select;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DOB {

	public static void main(String[] args) throws Throwable {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.facebook.com/signup");
		// Identify all three drop down
		List<WebElement> allDropDown = driver.findElements(By.xpath("//select[contains(@name,'birthday_')]"));
		// iterate each drop down

		for (WebElement dropDown : allDropDown) {
			// Choose the drop down upon the attribute value
			String dropdownType = dropDown.getAttribute("title");
			Select dropdownSelect = new Select(dropDown);

			if (dropdownType.equals("Day")) {
				// Choose the option-7th
				dropdownSelect.selectByVisibleText("7");

			} else if (dropdownType.equals("Month")) {
				// Choose the Month-Dec
				dropdownSelect.selectByVisibleText("Dec");

			} else if (dropdownType.equals("Year")) {
				// choose the Year option-1995
				dropdownSelect.selectByVisibleText("1995");
			}
		}

		Thread.sleep(6000);
		driver.manage().window().minimize();
		driver.quit();

	}

}