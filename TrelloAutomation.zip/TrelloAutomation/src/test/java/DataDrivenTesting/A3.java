package DataDrivenTesting;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v117.indexeddb.model.Key;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class A3 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(2));
		driver.get("https://www.facebook.com/");
		
		WebElement emailTextField = driver.switchTo().activeElement();
		Actions action =new Actions(driver);
		action.keyDown(Keys.SHIFT).sendKeys("ankita")
		.keyDown(Keys.CONTROL).sendKeys("a") .
		keyDown(Keys.CONTROL).sendKeys("x").keyUp(Keys.CONTROL).
		 sendKeys(emailTextField,(Keys.TAB)).perform();
		
		//single use up & combination use Down
		
		
		
		
		
		
		
		

	}

}
