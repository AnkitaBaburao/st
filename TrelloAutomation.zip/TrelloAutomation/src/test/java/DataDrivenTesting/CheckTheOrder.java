package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckTheOrder {

	public static void main(String[] args) throws EncryptedDocumentException, FileNotFoundException, IOException {
		List<String> expectedAllDayOptions = new ArrayList<String>();
		List<String> actualAllDayOptions = new ArrayList<String>();
		List<String> expectedAllMonthOptions =new ArrayList<String>();
		List<String>  actualAllMonthOptions =new ArrayList<String>();
	    List<String> expectedAllYearOptions = new ArrayList<String>();
		List<String> actualAllYearOptions = new ArrayList<String>();
		
		Workbook workbook = WorkbookFactory.create(new FileInputStream("./src/test/resources/myexcel2.xslm"));
		 Sheet sheet = workbook.getSheet("dob");
		
		
		for(int rowIndex=sheet.getFirstRowNum();rowIndex<=sheet.getLastRowNum();rowIndex++) {
			Row row =sheet.getRow(rowIndex);
			for(short cellIndex=row.getFirstCellNum();cellIndex<row.getLastCellNum();cellIndex++) {
				Cell cell=row.getCell(cellIndex);
				String cellType=cell.getCellType().toString();
				if(cellType.equals("STRING")) {
					expectedAllMonthOptions.add(cell.getStringCellValue())	;
					
				}else if(cellType.equals("NUMERIC")) {
					String cellData;
					if(row.getLastCellNum()==31) {
						expectedAllDayOptions.add(String.valueOf(long).cell.getNumericCellValue());
						
					}else {
						expectedAllYearOptions.add(String.valueOf(long)cell.getNumericCellValue());
						
					}
				}
			}
		}
		woorkbook.close();
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));

		driver.get("https://www.facebook.com/signup");

		List<WebElement> allDropdowns=driver.findElements(By.tagName("select"));

		for(WebElement dropdown : allDropdowns)

		{

		Select dropdownSelect = new Select(dropdown);

		List<WebElement> allOptions = dropdownSelect.getOptions();

		for(WebElement option : allOptions)

		{

		if(dropdown.getAttribute("title").equals("Day"))

		{

		actualAllDayOptions.add(option.getText());

		}

		else if (dropdown.getAttribute("title").equals("Month"))

		{

		actualAllMonthOptions.add(option.getText());

		}

		else if (dropdown.getAttribute("title").equals("Year"))

		{

		actualAllYearOptions.add(option.getText());

		}

		}

		}

		if(actualAllDayOptions.equals(expectedAllDayOptions))

		{

		System.out.println(actualAllDayOptions);

		System.out.println(expectedAllDayOptions);

		System.out.println("Pass: The Day Options Order is Found Correct and it is Verified");

		}

		else

		{

		System.out.println(actualAllDayOptions);

		System.out.println(expectedAllDayOptions);

		System.out.println("Fail: The Day Options Order is Found Incorrect and it is Verified");

		}

		if(actualAllMonthOptions.equals(expectedAllMonthOptions))

		{

		System.out.println(actualAllMonthOptions);

		System.out.println(expectedAllMonthOptions);

		System.out.println("Pass: The Month Options Order is Found Correct and it is Verified");

		}

		else

		{

		System.out.println(actualAllMonthOptions);

		System.out.println(expectedAllMonthOptions);

		System.out.println("Fail: The Month Options Order is Found Incorrect and it is Verified");

		}

		if(actualAllYearOptions.equals(expectedAllYearOptions))

		{

		System.out.println(actualAllYearOptions);

		System.out.println(expectedAllYearOptions);

		System.out.println("Pass: The Year Options Order is Found Correct and it is Verified");

		}

		else

		{

		System.out.println(actualAllYearOptions);

		System.out.println(expectedAllYearOptions);

		System.out.println("Fail: The Year Options Order is Found Incorrect and it is Verified");

		}

		driver.manage().window().minimize();

		driver.quit();

		}

}
