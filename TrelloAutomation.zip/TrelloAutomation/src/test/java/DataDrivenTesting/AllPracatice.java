package DataDrivenTesting;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;



public class AllPracatice {

	public static void main(String[] args) throws Throwable {
		FileInputStream fis=new FileInputStream("./src/test/resources/myexcel2.xlsm");
		Workbook workbook = WorkbookFactory.create(fis);
		Sheet sheet = workbook.getSheet("dob");
	
		int	 firstRowCountIndex = sheet.getFirstRowNum();
	System.out.println("firstRowCountIndex:"+firstRowCountIndex);
	
	int	 lastRowCountIndex = sheet.getLastRowNum();
	System.out.println("lastRowCountIndex:"+lastRowCountIndex);
	
	Row row = sheet.getRow(1);
	 
	short firstcellIndexCount = row.getFirstCellNum();
	System.out.println("firstcellIndexCount:"+firstcellIndexCount);
	
	 short lastcellCount = row.getLastCellNum();
	System.out.println("lastcellCount:"+lastcellCount);
	
	Cell cell= row.getCell(2);
	CellType cellType = cell.getCellType();
	System.out.println(cell.getCellType());
	
	if(cellType.toString().equals("STRING")){
		System.out.println(cell.getStringCellValue());
	}else if (cellType.toString().equals("NUMERIC")) {
		System.out.println((long)cell.getNumericCellValue());
	}
	workbook.close();	
	}
	}


