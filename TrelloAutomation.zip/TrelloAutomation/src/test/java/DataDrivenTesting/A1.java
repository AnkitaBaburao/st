package DataDrivenTesting;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class A1 {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(2));
		 driver.get("https://www.myntra.com/");
		 Actions action= new Actions(driver);
		 
		// WebElement menOption=driver.findElement(By.xpath("//div[@class='desktop-navContent']//a[@data-type='navElements']"));
		
		 WebElement menOption=driver.findElement(By.xpath("//div[@class='desktop-navLink']//a[text()='Men']"));
		 action.moveToElement(menOption).moveByOffset(73, 0).pause(2000).moveByOffset(74, 0).pause(2000).moveByOffset(98, 0).pause(2000).moveByOffset(108, 0).pause(2000).moveByOffset(83, 0).perform();

		 
	}

}
