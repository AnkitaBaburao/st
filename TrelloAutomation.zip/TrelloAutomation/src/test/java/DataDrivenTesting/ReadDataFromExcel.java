package DataDrivenTesting;

import java.io.FileInputStream;

import org.apache.commons.math3.analysis.function.Ceil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadDataFromExcel {

	public static void main(String[] args) throws Throwable {
		//Specify the address of the file to the FileInput Stream
		FileInputStream fis = new FileInputStream("./src/test/resource/myexcel.xlsx");
		
        //Callthe create () upon the WorkbookFactory Class of POI
		Workbook workbook = WorkbookFactory.create(fis);
		//specify the name of the sheet which u want the data
		//get into the sheet of the workbook
		Sheet sheet =workbook.getSheet("Sheet1");
		//get into row which u choose in the Sheet
		Row row= sheet.getRow(0);
		//specify the cell index in the selected Row
		 //Cell cell= row.getCell(0);
		Cell cell= row.getCell(0);
		
		//get the data from the cell-String-getStringCellValue()
		//Other data- IllegalStateException
		 String data= cell.getStringCellValue();
		 
		 System.out.println(data);
		  workbook.close();
		 
		
		
		
	}

}
