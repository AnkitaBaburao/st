package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadDataFromPropertyFile {

	public static void main(String[] args) throws IOException {
		//Give the fle path to FileInputStream .meanscurrent project
	FileInputStream fis=	new FileInputStream("./src/test/resource/cd.properties");
	//Creat the object of the Properties Class of the java
	Properties pobj=new Properties();
	//load the fis obj to pobj obj-load()
	pobj.load(fis);
	//choose the key of the value and pass it to-getpr
	String value = pobj.getProperty("url");
	System.out.println(value);
	
	String usernamevalue = pobj.getProperty("username");
	System.out.println(usernamevalue);
	

	}

}
