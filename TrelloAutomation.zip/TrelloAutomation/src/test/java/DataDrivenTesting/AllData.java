package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;



public class AllData {

	public static void main(String[] args)throws EncryptedDocumentException, IOException {
	List<String> expectedAllDayOptions = new ArrayList<String>();
	List<String> expectedAllMonthOptions =new ArrayList<String>();
	List<String> expectedAllYearOptions = new ArrayList<String>();
	
	
	
	Workbook workbook = WorkbookFactory.create(new FileInputStream("./src/test/resources/myexcel2.xslm"));
	 Sheet sheet = workbook.getSheet("dob");
	int firstRowIndexCount= sheet.getFirstRowNum();
	int lastRowIndexCount= sheet.getLastRowNum();
	
	for(int rowIndex= firstRowIndexCount; rowIndex<=lastRowIndexCount;rowIndex++ ) {
		Row row = sheet.getRow(rowIndex);
		short firstCellIndexCount = row.getFirstCellNum();
		short lastCellCount = row.getLastCellNum();
		
		for(short cellIndex = firstCellIndexCount; cellIndex<lastCellCount; cellIndex++) {
			Cell cell= row.getCell(cellIndex);
			if (cell.getCellType().toString().equals("STRING")) {
				String cellData= cell.getStringCellValue();
				System.out.println(cellData);
				expectedAllMonthOptions.add(cellData);
			}else if (cell.getCellType().toString().equals("NUMERIC")) {
				String cellData= String.valueOf((long)cell.getNumericCellValue());
				System.out.println(cellData);
				if (lastCellCount==31) {
					expectedAllDayOptions.add(cellData);
				}else {
					expectedAllYearOptions.add(cellData);
				}
			}
		}
		
	}
	workbook.close();
	System.out.println(expectedAllDayOptions);
	System.out.println(expectedAllMonthOptions);
	System.out.println(expectedAllYearOptions);
	
			

	}

}
