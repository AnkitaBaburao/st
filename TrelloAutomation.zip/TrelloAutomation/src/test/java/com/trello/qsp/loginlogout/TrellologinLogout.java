package com.trello.qsp.loginlogout;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TrellologinLogout {

	public static void main(String[] args) {
		//launch the target browser
		WebDriver driver = new ChromeDriver();
		//set the precondition of the script
		driver. manage().window().maximize();
		//Apply the implicit wait for the allthe invocation of findElement() in the below script
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		//trigger the main url of the application
		driver.get("https://trello.com/");
		//home page
		//identify the login option
		WebElement loginOption = driver.findElement(By.xpath("(//a[text()='Log in'])[1]"));
		Actions actions = new Actions(driver);
		actions
		

	}

}
