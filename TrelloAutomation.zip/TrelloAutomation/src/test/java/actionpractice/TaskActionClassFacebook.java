package actionpractice;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TaskActionClassFacebook {

	public static void main(String[] args) {
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(2));
	driver.get("https://www.facebook.com/");
	
	//Identify the user name
	 WebElement usernametextfield = driver.findElement(By.name("email"));
	 
	 Actions action= new Actions(driver);
	 action.sendKeys("ankita");
	 
	 //
	 WebElement passwordtextfield = driver.findElement(By.id("pass"));
	 action.sendKeys("12354678");
	 
	 WebElement loginButton = driver.findElement(By.name("login"));
	 action.moveToElement(loginButton).click().perform();
	}

}
