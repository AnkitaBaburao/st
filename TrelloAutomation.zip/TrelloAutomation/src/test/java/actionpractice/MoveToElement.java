package actionpractice;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MoveToElement {

	public static void main(String[] args) {
     WebDriver driver=new ChromeDriver();
     driver.manage().window().maximize();
     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
     WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
  
     driver.get("https://www.myntra.com/");
     
     //Identify the men menu action
 
     
     List<WebElement> allOptions = driver.findElements(By.xpath("//div[@class='desktop-navContent']//a[@data-type='navElements']"));
    
    //creat
    Actions actions= new Actions(driver);
    for (WebElement menuOption : allOptions) {
    	//action move to element(menuOption).pause(2000).perform
    	actions.moveToElement(menuOption).pause(Duration.ofSeconds(5)).perform();
    
    }
	}
		
	}
     

	


