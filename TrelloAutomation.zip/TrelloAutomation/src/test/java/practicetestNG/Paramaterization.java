package practicetestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

public class Paramaterization {
WebDriver driver;
@Parameters({"expectedTitle"})
@Test
public void verifyLoginPageTitle(String expectedTitlie) {
	Assert.assertEquals(driver.getTitle(),expectedTitlie,"The login page title is Found Incurrect");
}
public void checkForActive() {
String actualActiveEleAtt = driver.switchTo().activeElement().getAttribute("Place holder");
String expectedActiveEleAtt= "Email Address or Phone number";
Assert.assertEquals(actualActiveEleAtt, expectedActiveEleAtt, "The active element is incurrect)");
}
@AfterMethod
public void configAfterMethod() {
	driver. manage().window().minimize();
	driver.quit();
}
public void configBeforeMethod(String browserName, String url) {
	if (browserName.equals("chrome")) {
		driver= new ChromeDriver();
		}
	else if(browserName.equals("firefox")) {
		driver= new FirefoxDriver();
	}
	else if(browserName.equals("edge")) {
		driver= new EdgeDriver();
	}
	driver.manage().window().maximize();
	driver.get(url);
}
}