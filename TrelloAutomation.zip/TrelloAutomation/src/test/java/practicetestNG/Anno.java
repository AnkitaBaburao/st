package practicetestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Anno {
     @BeforeClass
	public void beforeClass() {
		System.out.println("beforeClass");
	}@AfterClass
	public void afterClass() {
		System.out.println("afterClass");
}@BeforeMethod
	public void beforeMethod() {
		System.out.println("beforeMethod");
}@AfterMethod
	public void afterMethod() {
		System.out.println("afterMethod");	
	}@Test
	public void testA() {
		System.out.println("testA");	
	}
	public void testb() {
		System.out.println("testb");	
	}
	public void beforeSuit() {
		System.out.println("beforeSuit");	
	}
	public void afterSuit() {
		System.out.println("afterSuit");
	}
}
	
	