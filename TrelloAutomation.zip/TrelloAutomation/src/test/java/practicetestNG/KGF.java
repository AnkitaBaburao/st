package practicetestNG;

import org.testng.annotations.Test;

public class KGF {
	
public void rockyTest() {
System.out.println("rockyTest");
}
@Test

public void reenaTest() {
System.out.println("reenaTest");
}
public void adhiraTest() {
System.out.println("adhiraTest");
}
public void pmTest() {
System.out.println("pmTest");
}
}