package practicetestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AllPopups {
	WebDriver driver;

	@BeforeMethod 
	public void configBeforeMethod() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
  public void hiddenDivisionPopups() {
	  driver.get("https://www.flipkart.com/");
	  WebElement closePopupsButton= driver.findElement(By.xpath("//span[text()='✕']"));
	  closePopupsButton.click();
  }
@Test
	public void ajioCheck()throws Throwable{ 
   ChromeOptions option = new ChromeOptions();
  option.addArguments("--disable-notification");
  driver = new ChromeDriver(option);
  driver.manage().window().maximize();
  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
  driver.get("https://pib.gov.in/");
  //handle the error message
  //get the alter message
  Thread.sleep(5000);
  
  System.out.println(driver.switchTo().alert().getText());
  
  //click on OK button
  driver.switchTo().alert().accept();
  WebElement minOfDef = driver .findElement(By.xpath("//a[text()='Ministry of Defence']"));
  Actions action = new Actions(driver);
 //conformation popup
  System.out.println(driver.switchTo().alert().getText());
  driver.switchTo().alert().accept();
	}
}
