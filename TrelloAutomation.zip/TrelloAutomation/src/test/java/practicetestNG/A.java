package practicetestNG;

import org.testng.annotations.Test;

public class A {
	
	@Test (groups={"functional"})
	public void apple(){
		System.out.println("Apple execution");
	}
	
	@Test(groups={"integration"})
	public void mango() {
	System.out.println("Mango execution ");	
	}
	
	@Test(groups={"functional,integration"})
	public void graps() {
		System.out.println();
	}
	
	@Test(groups={"functional,smoke"})
	public void draganFruit() {
		System.out.println();
	}
	
}
