package practicetestNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class BookFlight {
@Test(dataProvider = "ticketData")
public void ticket(String name,String mobNo,String age, String src, String dest) {
	System.out.println("Hellow I am:"+name+"My Phone No is:"+mobNo+"My age:"+age+"I am coming:"+src+"goTo"+dest);
	
}
@DataProvider
public Object[][] ticketData(){
	Object[][] obj=new Object[3][5];
	obj[0][0]="Parth";
	obj[0][1]="23456789";
	obj[0][2]="14";
	obj[0][3]="kolhapur";
	obj[0][4]="Pune";
	
	obj[1][0]="Anuj";
	obj[1][1]="345678";
	obj[1][2]="45";
	obj[1][3]="KOpargaon";
	obj[0][4]="Mumbai"	;
	
	obj[2][0]="dfg";
	obj[2][1]="34567";
	obj[2][2]="34";
	obj[2][3]="fdgh";
	obj[2][4]="rtghj";
	
	return  obj;
}
}
