package practicetestNG;

import org.testng.annotations.Test;

public class FaceBook {
	@Test(priority=1, invocationCount=2)
public void creatAccount() {
	int[]a= {0,1,2};
	System.out.println((a[1]));
	System.out.println("creatAccount");
}
	@Test (priority=11)
public void deleteAccount() {
	System.out.println("deleteAccount");
	
}@Test (priority=2, dependsOnMethods = {"creatAccount"})
	public void loginToYourAccount() {
	System.out.println("loginToYourAccount");
}

public void sendFriendRequest() {
	System.out.println("sendFriendRequest");
}
public void deleteFriendrequest() {
	System.out.println("deleteFriendrequest");
}
@Test (priority=8)
public void uploadDp() {
	System.out.println("uploadDp");
}
@Test (priority=8)
public void changeDp() {
	System.out.println("changeDp");
}
@Test (priority=5, dependsOnMethods = {"creatAccount"})
public void creatPost() {
	System.out.println("creatPost");
}
@Test (priority=6)
public void likePost() {
	System.out.println("likePost");
}
@Test (priority=9)
public void deletePost() {
	System.out.println("deletePost");
}
@Test (priority=7)
public void commentPost() {
	System.out.println("commentPost");
}
}
