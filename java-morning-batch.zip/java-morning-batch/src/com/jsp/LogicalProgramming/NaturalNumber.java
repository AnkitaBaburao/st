package com.jsp.LogicalProgramming;

public class NaturalNumber {
public static void  printNaturalNumber(int start,int endlimit) {
	for(int i=start;i<=endlimit;i++) {
		System.out.print(i+" ");
	}
}
	public static void main(String[] args) {
		printNaturalNumber(1,100);

	}

}
