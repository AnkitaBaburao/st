package com.jsp.LogicalProgramming;

public class FactorialNumber {
//5=5*4*3*2*1
	public static int printFactorialNumber(int n) {
		int pro=1;
		for(int i=1;i<=n;i++) {
			pro=pro*i;}
				return pro;
			}
		
	
	
	public static void main(String[] args) {
		printFactorialNumber(5);
System.out.println(printFactorialNumber(5));
	}

}
