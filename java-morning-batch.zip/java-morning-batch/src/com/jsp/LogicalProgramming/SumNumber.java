package com.jsp.LogicalProgramming;

public class SumNumber {
public static void printSumNumber(int n) {
	int sum=0;
	for(int i=1;i<=n;i++) {
		sum+=i;
	System.out.println(i+" ")	;
	
	}
}
	public static void main(String[] args) {
		
printSumNumber(5);
	}

}
