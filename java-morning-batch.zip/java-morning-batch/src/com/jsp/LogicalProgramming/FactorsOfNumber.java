package com.jsp.LogicalProgramming;

public class FactorsOfNumber {
//9=1*3*9
	public static void printFactorsOfNumber(int n) {
		for(int i=1;i<=n;i++) {
			if(n%i==0)
				System.out.println(i+" ");
		}
	}
	public static void main(String[] args) {
	printFactorsOfNumber(9);

	}

}
